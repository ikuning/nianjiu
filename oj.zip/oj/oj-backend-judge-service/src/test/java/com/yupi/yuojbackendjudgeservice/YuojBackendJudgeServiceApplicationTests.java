package com.yupi.yuojbackendjudgeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YuojBackendJudgeServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
